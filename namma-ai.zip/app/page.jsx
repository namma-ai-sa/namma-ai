"use client";

import Navbar from "./components/Navbar";
import { useRouter } from "next/navigation";

export default function HomePage() {
  const router = useRouter();

  const features = [
    {
      icon: "📊",
      title: "CRM الذكي",
      desc: "إدارة العملاء والمتابعات وتحسين فرص الإغلاق."
    },
    {
      icon: "🤖",
      title: "البائع الذكي",
      desc: "تحليل احتمالية الشراء وتوصيات المبيعات."
    },
    {
      icon: "📱",
      title: "وكيل واتساب",
      desc: "تحليل المحادثات واقتراح الردود المناسبة."
    },
    {
      icon: "⚡",
      title: "لوحة الإدارة",
      desc: "إحصائيات ومؤشرات أداء المنصة بالكامل."
    }
  ];

  const stats = [
    {
      value: "+5000",
      label: "رسالة تم تحليلها"
    },
    {
      value: "+300",
      label: "عميل تمت متابعته"
    },
    {
      value: "24/7",
      label: "مساعد ذكي متاح"
    },
    {
      value: "90%",
      label: "تحسين سرعة المتابعة"
    }
  ];

  return (
    <>
      <Navbar />

      <main
        style={{
          minHeight: "100vh",
          background:
            "linear-gradient(180deg,#020617,#0f172a,#111827)",
          color: "white",
          padding: "40px 20px"
        }}
      >
        <section
          style={{
            maxWidth: "1200px",
            margin: "0 auto",
            textAlign: "center",
            paddingTop: "80px"
          }}
        >
          <div
            style={{
              display: "inline-block",
              padding: "10px 18px",
              border: "1px solid rgba(34,197,94,.3)",
              background: "rgba(34,197,94,.08)",
              borderRadius: "999px",
              color: "#22c55e",
              fontWeight: "700",
              marginBottom: "25px"
            }}
          >
            🌱 نمّى AI | وكيل النمو الذكي
          </div>

          <h1
            style={{
              fontSize: "72px",
              fontWeight: "900",
              lineHeight: "1.2",
              marginBottom: "24px"
            }}
          >
            وكيل المبيعات الذكي
            <br />
            للشركات العربية
          </h1>

          <p
            style={{
              maxWidth: "850px",
              margin: "0 auto",
              color: "#cbd5e1",
              fontSize: "22px",
              lineHeight: "2"
            }}
          >
            اجمع CRM الذكي والبائع الذكي ووكيل واتساب
            وصناعة المحتوى وتحليل العملاء
            داخل منصة واحدة مصممة لزيادة المبيعات
            وتحسين تجربة العميل.
          </p>

          <div
            style={{
              display: "flex",
              gap: "16px",
              justifyContent: "center",
              flexWrap: "wrap",
              marginTop: "40px"
            }}
          >
            <button
              onClick={() => router.push("/register")}
              style={{
                padding: "16px 32px",
                border: "none",
                borderRadius: "14px",
                background: "#22c55e",
                color: "white",
                cursor: "pointer",
                fontWeight: "bold"
              }}
            >
              ابدأ مجاناً
            </button>

            <button
              onClick={() => router.push("/pricing")}
              style={{
                padding: "16px 32px",
                borderRadius: "14px",
                border: "1px solid rgba(255,255,255,.15)",
                background: "transparent",
                color: "white",
                cursor: "pointer"
              }}
            >
              شاهد الأسعار
            </button>
          </div>
        </section>

        <section
          style={{
            maxWidth: "1200px",
            margin: "80px auto"
          }}
        >
          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fit,minmax(220px,1fr))",
              gap: "20px"
            }}
          >
            {stats.map((item) => (
              <div
                key={item.label}
                style={{
                  background: "rgba(255,255,255,.04)",
                  border:
                    "1px solid rgba(255,255,255,.08)",
                  borderRadius: "20px",
                  padding: "24px",
                  textAlign: "center"
                }}
              >
                <h2
                  style={{
                    color: "#22c55e",
                    fontSize: "34px",
                    fontWeight: "900"
                  }}
                >
                  {item.value}
                </h2>

                <p
                  style={{
                    color: "#cbd5e1"
                  }}
                >
                  {item.label}
                </p>
              </div>
            ))}
          </div>
        </section>

        <section
          style={{
            maxWidth: "1200px",
            margin: "80px auto"
          }}
        >
          <div
            style={{
              display: "grid",
              gridTemplateColumns:
                "repeat(auto-fit,minmax(250px,1fr))",
              gap: "20px"
            }}
          >
            {features.map((item) => (
              <div
                key={item.title}
                style={{
                  background: "rgba(255,255,255,.04)",
                  border:
                    "1px solid rgba(255,255,255,.08)",
                  borderRadius: "20px",
                  padding: "30px"
                }}
              >
                <div
                  style={{
                    fontSize: "48px",
                    marginBottom: "12px"
                  }}
                >
                  {item.icon}
                </div>

                <h3>{item.title}</h3>

                <p
                  style={{
                    color: "#cbd5e1",
                    lineHeight: "1.8"
                  }}
                >
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </section>
      </main>
    </>
  );
}